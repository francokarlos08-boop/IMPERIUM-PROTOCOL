# IMPERIUM PROTOCOL (Imperium Labs)

Aplicación web local de hábitos, misiones y progresión. Sin cuentas, sin nube, sin costes. Los datos viven en IndexedDB de tu navegador.

## Requisitos
- Windows con **Node.js 20 o superior** (LTS recomendado) y un navegador moderno (Chrome/Edge).
- Internet solo para `npm install`. Después funciona sin conexión.

## Ejecutar (PowerShell)
1. Abre la carpeta en VS Code (Archivo → Abrir carpeta) y abre la terminal (Ctrl+`). Debe estar en la carpeta que contiene `package.json`.
2. `npm install`
3. `npm run dev` → abre http://localhost:5173
4. Para detener el servidor: Ctrl+C. (Es solo una herramienta local; no hay servidor externo.)

## Pruebas y compilación
- `npm run test` — pruebas de la lógica (hábitos, XP, rachas, estadísticas, copias).
- `npm run build` — comprueba tipos y compila a `dist/`.
- `npm run preview` — sirve la versión compilada en http://127.0.0.1:4173. **Ábrela una vez con conexión local** (el service worker guarda los archivos al visitarlos); después funciona aunque no haya internet. El service worker solo se registra en la versión compilada y requiere `localhost` o HTTPS; abrir `index.html` directamente no funcionará.
- Instalar como PWA: en Edge/Chrome, icono de instalar en la barra de direcciones, desde la versión `preview`.

## Copias de seguridad
Configuración → «Exportar copia JSON». Para restaurar: «Importar copia»; se valida el archivo y se pide confirmación antes de reemplazar nada. Un archivo inválido no modifica tus datos. Haz copias periódicas: borrar los datos del sitio en el navegador elimina los registros.

## Reglas de cálculo
- **Estados**: completado, no completado, sin registrar (no hay registro; no es incumplimiento), no programado.
- **XP** (derivada de los registros, nunca acumulada a mano): XP por hábito completado en un día programado y no futuro; +25 por día con todos los hábitos programados completados; +100 por semana (lunes–domingo) terminada con todo cumplido; las misiones dan su XP una sola vez (`rewardGranted`), aunque se reabran.
- **Nivel**: la XP necesaria para el nivel n es 50·n·(n−1). Rango cada 4 niveles (8 rangos).
- **Racha**: día exitoso = hay hábitos programados y todos completados. Hoy pendiente no rompe la racha; un día pasado incompleto o sin registrar sí. Días sin hábitos programados y días futuros se ignoran.
- **Porcentajes**: completados / (completados + no completados) sobre oportunidades programadas ya llegadas. Los pendientes se muestran aparte. Los hábitos semanales no entran en el porcentaje diario.
- **Archivar**: el hábito deja de programarse desde esa fecha; el historial se conserva. No hay borrado individual (solo «Borrar todos los datos»).

## Solución de problemas
- `npm` no se reconoce: reinstala Node.js y reinicia VS Code.
- El puerto está ocupado: `npm run dev -- --port 5180`.
- Aviso de almacenamiento: no uses ventana privada y libera espacio.
