import { useCallback, useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { db, exportAll, importAll, loadAll, saveSettings, uid, wipeAll } from './db.ts';
import { DEFAULTS, completeMission, eligible, index, isDaily, levelInfo, periodStats, reopenMission, setLog, streaks, xpBreakdown } from './logic/core.ts';
import type { Habit, Log, Mission, Settings } from './logic/core.ts';
import { addDays, key, range } from './logic/dates.ts';

const PAGES = ['Dashboard', 'Hábitos', 'Misiones', 'Estadísticas', 'Logros', 'Configuración'] as const;
const CATS = ['Físico', 'Estudios', 'Programación', 'Ciberseguridad', 'Imperium Labs', 'Desarrollo personal', 'Descanso y bienestar', 'Personalizado'];
const DAYS = ['D', 'L', 'M', 'X', 'J', 'V', 'S'];
const pct = (n: number | null) => (n === null ? '—' : `${Math.round(n * 100)}%`);
type Data = { habits: Habit[]; logs: Log[]; missions: Mission[]; settings: Settings };
type Ask = { text: string; ok: () => void } | null;

export default function App() {
  const [page, setPage] = useState<(typeof PAGES)[number]>('Dashboard');
  const [d, setD] = useState<Data | null>(null);
  const [toast, setToast] = useState<{ t: string; err?: boolean } | null>(null);
  const [ask, setAsk] = useState<Ask>(null);
  const lvl = useRef<number | null>(null);
  const today = key(new Date());
  const say = (t: string, err = false) => { setToast({ t, err }); setTimeout(() => setToast(null), 4000); };

  const reload = useCallback(async () => {
    try {
      const a = await loadAll(); setD(a);
      const l = levelInfo(xpBreakdown(a.habits, a.logs, a.missions, a.settings, key(new Date())).total).level;
      if (lvl.current !== null && l > lvl.current) say(`Nivel ${l} alcanzado`);
      lvl.current = l;
    } catch { say('No se pudo acceder al almacenamiento local (IndexedDB). Comprueba que el navegador no esté en modo privado y que haya espacio libre.', true); }
  }, []);
  useEffect(() => { reload(); }, [reload]);
  const run = async (f: () => Promise<unknown>, ok?: string) => { try { await f(); await reload(); if (ok) say(ok); } catch { say('No se pudo guardar el cambio. Reintenta; si persiste, exporta una copia y recarga la página.', true); } };

  if (!d) return <main>{toast ? <p>{toast.t}</p> : <p>Cargando…</p>}</main>;
  const xp = xpBreakdown(d.habits, d.logs, d.missions, d.settings, today), L = levelInfo(xp.total);
  const P = { d, today, run, setAsk, say, xp, L };
  return (
    <div className={`app ${d.settings.reduceMotion ? 'red' : ''}`}>
      <nav aria-label="Principal">
        <div className="brand"><svg width="28" height="28" viewBox="0 0 64 64" aria-hidden><path d="M32 8 54 20v24L32 56 10 44V20z" fill="none" stroke="#27E0C3" strokeWidth="5" /><path d="M32 20v24M20 26l12 6 12-6" fill="none" stroke="#27E0C3" strokeWidth="5" /></svg>IMPERIUM PROTOCOL</div>
        {PAGES.map(p => <button key={p} aria-current={p === page ? 'page' : undefined} onClick={() => setPage(p)}>{p}</button>)}
      </nav>
      <main>
        {page === 'Dashboard' && <Dashboard {...P} go={setPage} />}
        {page === 'Hábitos' && <Habits {...P} />}
        {page === 'Misiones' && <Missions {...P} />}
        {page === 'Estadísticas' && <Stats {...P} />}
        {page === 'Logros' && <Achievements {...P} />}
        {page === 'Configuración' && <Config {...P} reload={reload} />}
      </main>
      {toast && <div className={`toast ${toast.err ? 'err' : ''}`} role="status">{toast.t}</div>}
      {ask && <div className="dlg" role="dialog" aria-modal="true"><div><p>{ask.text}</p><button className="b" autoFocus onClick={() => setAsk(null)}>Cancelar</button>{' '}<button className="b dng" onClick={() => { ask.ok(); setAsk(null); }}>Confirmar</button></div></div>}
    </div>
  );
}
type PP = { d: Data; today: string; run: (f: () => Promise<unknown>, ok?: string) => Promise<void>; setAsk: (a: Ask) => void; say: (t: string, e?: boolean) => void; xp: ReturnType<typeof xpBreakdown>; L: ReturnType<typeof levelInfo> };
const Bar = ({ v, label }: { v: number; label: string }) => <div className="bar" role="progressbar" aria-label={label} aria-valuenow={Math.round(v * 100)} aria-valuemin={0} aria-valuemax={100}><i style={{ width: `${Math.max(0, Math.min(1, v)) * 100}%` }} /></div>;

function Dashboard({ d, today, L, xp, go }: PP & { go: (p: any) => void }) {
  const h = d.habits.filter(x => !x.archivedOn);
  const hr = new Date().getHours(), greet = hr < 12 ? 'Buenos días' : hr < 20 ? 'Buenas tardes' : 'Buenas noches';
  const st = streaks(d.habits, d.logs, today), t = periodStats(d.habits, d.logs, today, today, today);
  const week = periodStats(d.habits, d.logs, addDays(today, -6), today, today), month = periodStats(d.habits, d.logs, today.slice(0, 8) + '01', today, today);
  const open = d.missions.filter(m => ['pendiente', 'progreso'].includes(m.status));
  const soon = open.filter(m => m.due && m.due <= addDays(today, 3)).sort((a, b) => a.due!.localeCompare(b.due!));
  const total = t.done + t.missed + t.pending;
  const days14 = range(addDays(today, -13), today).map(k => ({ k, p: periodStats(d.habits, d.logs, k, k, today).pct }));
  const recent = [...d.logs].filter(l => l.status === 'done').sort((a, b) => b.date.localeCompare(a.date)).slice(0, 5);
  const name = (id: string) => d.habits.find(x => x.id === id)?.name ?? 'Hábito eliminado';
  if (!h.length && !d.logs.length) return <div className="card empty"><h1>Bienvenido a IMPERIUM PROTOCOL</h1><p className="sub">Define hábitos, completa misiones y sube de rango. Todo se guarda solo en este equipo.</p><button className="b pri" onClick={() => go('Hábitos')}>Crear primer hábito</button></div>;
  return <>
    <h1>{greet}, {d.settings.name}</h1><p className="sub">{new Date().toLocaleDateString('es', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</p>
    <div className="grid">
      <div className="card"><div className="mut">Nivel y rango</div><div className="big">Nivel {L.level}</div><div>{L.rank}</div></div>
      <div className="card"><div className="mut">XP total {xp.total}</div><Bar v={L.pct} label="Progreso al siguiente nivel" /><div className="mut">Faltan {L.remaining} XP para el nivel {L.level + 1}</div></div>
      <div className="card"><div className="mut">Hoy</div><div className="big">{pct(t.pct)}</div><div className="mut">{t.done} completados · {total - t.done} pendientes de {total}</div></div>
      <div className="card"><div className="mut">Racha</div><div className="big">{st.current} días</div><div className="mut">Mejor: {st.best}</div></div>
    </div>
    <div className="grid">
      <div className="card"><h2>Semana (7 días)</h2><div className="big">{pct(week.pct)}</div><Bar v={week.pct ?? 0} label="Cumplimiento semanal" /></div>
      <div className="card"><h2>Mes</h2><div className="big">{pct(month.pct)}</div><Bar v={month.pct ?? 0} label="Cumplimiento mensual" /><div className="mut">{month.done} completados, {month.missed} no completados, {month.pending} sin registrar</div></div>
      <div className="card"><h2>Misiones activas: {open.length}</h2>{soon.length ? soon.map(m => <div key={m.id} className="mut">{m.title} · vence {m.due}</div>) : <div className="mut">Ninguna vence en 3 días.</div>}</div>
    </div>
    <div className="card"><h2>Cumplimiento diario (14 días)</h2><svg viewBox="0 0 280 80" width="100%" role="img" aria-label={`Cumplimiento diario: ${days14.map(x => `${x.k} ${pct(x.p)}`).join(', ')}`}>
      {days14.map((x, i) => <g key={x.k}><rect x={i * 20 + 2} y={0} width={16} height={70} fill="#1B2129" />{x.p !== null && <rect x={i * 20 + 2} y={70 - x.p * 70} width={16} height={x.p * 70} fill="#27E0C3" />}</g>)}</svg>
      <div className="mut">Las barras vacías indican días sin datos evaluables.</div></div>
    <div className="card" style={{ marginTop: 14 }}><h2>Actividad reciente</h2>{recent.length ? recent.map(l => <div key={l.habitId + l.date} className="mut">{l.date} · {name(l.habitId)}</div>) : <div className="mut">Aún no hay hábitos completados.</div>}</div>
    <p className="mut">{t.pending === 0 && total > 0 ? 'Día completo. Buen trabajo.' : st.current > 0 ? `Llevas ${st.current} días seguidos: mantén el ritmo.` : 'Completa tu primer hábito de hoy para empezar la racha.'}</p>
  </>;
}

function Habits({ d, today, run, setAsk }: PP) {
  const [date, setDate] = useState(today); const [cat, setCat] = useState(''); const [freq, setFreq] = useState(''); const [state, setState] = useState('activo');
  const blank = { name: '', category: CATS[0], frequency: 'daily' as Habit['frequency'], days: [] as number[], weeklyTarget: 3 };
  const [f, setF] = useState(blank); const [edit, setEdit] = useState<string | null>(null); const [err, setErr] = useState('');
  const ix = index(d.logs);
  const list = d.habits.filter(h => (!cat || h.category === cat) && (!freq || h.frequency === freq) && (state === 'activo' ? !h.archivedOn : !!h.archivedOn));
  const save = () => {
    if (!f.name.trim()) return setErr('Escribe un nombre para el hábito.');
    if (f.frequency === 'days' && !f.days.length) return setErr('Elige al menos un día de la semana.');
    setErr('');
    run(async () => { if (edit) await db.habits.update(edit, { ...f, name: f.name.trim() }); else await db.habits.put({ ...f, name: f.name.trim(), id: uid(), startDate: today }); setF(blank); setEdit(null); }, edit ? 'Hábito actualizado' : 'Hábito creado');
  };
  const mark = (h: Habit, s: Log['status'] | null) => run(() => s ? db.logs.put({ habitId: h.id, date, status: s }) : db.logs.delete([h.id, date]));
  return <>
    <h1>Hábitos</h1><p className="sub">Registra por fecha. «Sin registrar» no cuenta como incumplimiento.</p>
    <form className="f card" onSubmit={e => { e.preventDefault(); save(); }}>
      <label>Nombre<input value={f.name} onChange={e => setF({ ...f, name: e.target.value })} /></label>
      <label>Categoría<select value={f.category} onChange={e => setF({ ...f, category: e.target.value })}>{CATS.map(c => <option key={c}>{c}</option>)}</select></label>
      <label>Frecuencia<select value={f.frequency} onChange={e => setF({ ...f, frequency: e.target.value as Habit['frequency'] })}><option value="daily">Diaria</option><option value="days">Días específicos</option><option value="weekly">Semanal</option></select></label>
      {f.frequency === 'days' && <fieldset><legend className="mut">Días</legend>{DAYS.map((n, i) => <label key={i} style={{ display: 'inline-flex', gap: 4, marginRight: 8 }}><input type="checkbox" checked={f.days.includes(i)} onChange={e => setF({ ...f, days: e.target.checked ? [...f.days, i] : f.days.filter(x => x !== i) })} />{n}</label>)}</fieldset>}
      {f.frequency === 'weekly' && <label>Veces por semana<input type="number" min={1} max={7} value={f.weeklyTarget} onChange={e => setF({ ...f, weeklyTarget: Number(e.target.value) })} /></label>}
      <div><button className="b pri">{edit ? 'Guardar cambios' : 'Crear hábito'}</button>{edit && <button type="button" className="b" onClick={() => { setEdit(null); setF(blank); }}>Cancelar</button>}</div>
      {err && <div role="alert" className="tag bad">{err}</div>}
    </form>
    <div className="row"><label>Fecha<input type="date" max={today} value={date} onChange={e => e.target.value && setDate(e.target.value)} /></label>
      <label>Categoría<select value={cat} onChange={e => setCat(e.target.value)}><option value="">Todas</option>{CATS.map(c => <option key={c}>{c}</option>)}</select></label>
      <label>Frecuencia<select value={freq} onChange={e => setFreq(e.target.value)}><option value="">Todas</option><option value="daily">Diaria</option><option value="days">Días específicos</option><option value="weekly">Semanal</option></select></label>
      <label>Estado<select value={state} onChange={e => setState(e.target.value)}><option value="activo">Activos</option><option value="archivado">Archivados</option></select></label></div>
    <div className="card">{list.length === 0 && <div className="mut">No hay hábitos con estos filtros.</div>}
      {list.map(h => { const l = ix.get(`${h.id}|${date}`); const sch = h.frequency === 'weekly' ? date >= h.startDate : eligible(h, date);
        return <div className="row" key={h.id}><div className="grow"><b>{h.name}</b><div className="mut">{h.category} · {h.frequency === 'daily' ? 'Diaria' : h.frequency === 'weekly' ? `${h.weeklyTarget}/semana` : h.days.map(i => DAYS[i]).join(' ')}</div></div>
          <span className={`tag ${l?.status === 'done' ? 'ok' : l?.status === 'missed' ? 'bad' : ''}`}>{!sch ? 'No programado' : l?.status === 'done' ? 'Completado' : l?.status === 'missed' ? 'No completado' : 'Sin registrar'}</span>
          {sch && !h.archivedOn && <><button className="b pri" onClick={() => mark(h, 'done')} disabled={l?.status === 'done'}>Completar</button><button className="b" onClick={() => mark(h, 'missed')} disabled={l?.status === 'missed'}>No completado</button>{l && <button className="b" onClick={() => mark(h, null)}>Deshacer</button>}</>}
          {!h.archivedOn ? <><button className="b" onClick={() => { setEdit(h.id); setF({ name: h.name, category: h.category, frequency: h.frequency, days: h.days, weeklyTarget: h.weeklyTarget }); window.scrollTo(0, 0); }}>Editar</button>
            <button className="b dng" onClick={() => setAsk({ text: `¿Archivar «${h.name}»? Su historial se conserva y deja de programarse desde hoy.`, ok: () => run(() => db.habits.update(h.id, { archivedOn: today }), 'Hábito archivado') })}>Archivar</button></>
            : <button className="b" onClick={() => run(() => db.habits.update(h.id, { archivedOn: undefined }), 'Hábito restaurado')}>Restaurar</button>}</div>; })}</div>
  </>;
}

function Missions({ d, today, run, setAsk }: PP) {
  const blank = { title: '', category: CATS[0], priority: 'media' as Mission['priority'], due: '', xp: 50 };
  const [f, setF] = useState(blank); const [st, setSt] = useState(''); const [pr, setPr] = useState(''); const [err, setErr] = useState('');
  const add = () => { if (!f.title.trim()) return setErr('Escribe un título para la misión.'); if (f.xp < 0) return setErr('La XP no puede ser negativa.'); setErr('');
    run(async () => { await db.missions.put({ id: uid(), title: f.title.trim(), description: '', category: f.category, priority: f.priority, due: f.due || undefined, xp: f.xp, status: 'pendiente', progress: 0, created: today, rewardGranted: false }); setF(blank); }, 'Misión creada'); };
  const upd = (m: Mission, ch: Partial<Mission>, ok?: string) => run(() => db.missions.put({ ...m, ...ch }), ok);
  const list = d.missions.filter(m => (!st || m.status === st) && (!pr || m.priority === pr)).sort((a, b) => (a.due ?? '9').localeCompare(b.due ?? '9'));
  return <>
    <h1>Misiones</h1><p className="sub">Objetivos independientes de los hábitos. La XP se concede una sola vez por misión.</p>
    <form className="f card" onSubmit={e => { e.preventDefault(); add(); }}>
      <label>Título<input value={f.title} onChange={e => setF({ ...f, title: e.target.value })} /></label>
      <label>Categoría<select value={f.category} onChange={e => setF({ ...f, category: e.target.value })}>{CATS.map(c => <option key={c}>{c}</option>)}</select></label>
      <label>Prioridad<select value={f.priority} onChange={e => setF({ ...f, priority: e.target.value as Mission['priority'] })}><option>alta</option><option>media</option><option>baja</option></select></label>
      <label>Fecha límite<input type="date" value={f.due} onChange={e => setF({ ...f, due: e.target.value })} /></label>
      <label>XP de recompensa<input type="number" min={0} value={f.xp} onChange={e => setF({ ...f, xp: Number(e.target.value) })} /></label>
      <div><button className="b pri">Crear misión</button></div>{err && <div role="alert" className="tag bad">{err}</div>}
    </form>
    <div className="row"><label>Estado<select value={st} onChange={e => setSt(e.target.value)}><option value="">Todos</option>{['pendiente', 'progreso', 'completada', 'pospuesta', 'cancelada'].map(s => <option key={s}>{s}</option>)}</select></label>
      <label>Prioridad<select value={pr} onChange={e => setPr(e.target.value)}><option value="">Todas</option><option>alta</option><option>media</option><option>baja</option></select></label></div>
    <div className="card">{list.length === 0 && <div className="mut">No hay misiones con estos filtros.</div>}
      {list.map(m => { const late = m.due && m.due < today && !['completada', 'cancelada'].includes(m.status);
        return <div className="row" key={m.id}><div className="grow"><b>{m.title}</b><div className="mut">{m.category} · prioridad {m.priority} · {m.xp} XP{m.due ? ` · límite ${m.due}` : ''}</div>
          <Bar v={m.progress / 100} label={`Progreso de ${m.title}`} /></div>
          <span className={`tag ${m.status === 'completada' ? 'ok' : late ? 'bad' : ''}`}>{late ? 'Vencida' : m.status}</span>
          {m.status !== 'completada' ? <><input type="number" min={0} max={100} aria-label="Progreso %" style={{ width: 70 }} value={m.progress} onChange={e => upd(m, { progress: Math.max(0, Math.min(100, Number(e.target.value))), status: m.status === 'pendiente' ? 'progreso' : m.status })} />
            <button className="b pri" onClick={() => run(() => db.missions.put(completeMission(m, today)), m.rewardGranted ? 'Misión completada (sin XP repetida)' : `Misión completada: +${m.xp} XP`)}>Completar</button>
            <button className="b" onClick={() => upd(m, { status: 'pospuesta' }, 'Misión pospuesta')}>Posponer</button></>
            : <button className="b" onClick={() => run(() => db.missions.put(reopenMission(m)), 'Misión reabierta; no concede XP de nuevo')}>Reabrir</button>}
          <button className="b dng" onClick={() => setAsk({ text: `¿Eliminar «${m.title}»? ${m.rewardGranted ? 'La XP ya concedida se perderá.' : ''}`, ok: () => run(() => db.missions.delete(m.id), 'Misión eliminada') })}>Eliminar</button></div>; })}</div>
  </>;
}

function Stats({ d, today }: PP) {
  const [n, setN] = useState(30); const from = addDays(today, -(n - 1));
  const s = periodStats(d.habits, d.logs, from, today, today);
  const days = range(from, today).map(k => ({ k, p: periodStats(d.habits, d.logs, k, k, today).pct }));
  const enough = s.done + s.missed >= 3;
  return <>
    <h1>Estadísticas</h1><p className="sub">Solo cuentan oportunidades programadas que ya llegaron. Los registros pendientes se muestran aparte.</p>
    <label>Periodo<select value={n} onChange={e => setN(Number(e.target.value))}><option value={7}>7 días</option><option value={30}>30 días</option><option value={90}>90 días</option></select></label>
    <div className="grid" style={{ marginTop: 14 }}>
      <div className="card"><div className="mut">Cumplimiento</div><div className="big">{pct(s.pct)}</div></div>
      <div className="card"><div className="mut">Completados</div><div className="big">{s.done}</div></div>
      <div className="card"><div className="mut">No completados</div><div className="big">{s.missed}</div></div>
      <div className="card"><div className="mut">Sin registrar</div><div className="big">{s.pending}</div></div>
    </div>
    {!enough ? <div className="card mut">Aún no hay suficientes registros evaluados en este periodo para mostrar tendencias.</div> : <>
      <div className="card"><h2>Evolución diaria</h2><svg viewBox={`0 0 ${days.length * 10} 80`} width="100%" role="img" aria-label={`Cumplimiento diario de los últimos ${n} días: promedio ${pct(s.pct)}`}>
        {days.map((x, i) => x.p !== null && <rect key={x.k} x={i * 10 + 1} y={70 - x.p * 70} width={8} height={Math.max(1, x.p * 70)} fill="#27E0C3"><title>{x.k}: {pct(x.p)}</title></rect>)}</svg></div>
      <div className="card" style={{ marginTop: 14 }}><h2>Por hábito</h2><table><thead><tr><th>Hábito</th><th>Completados</th><th>No completados</th><th>Sin registrar</th><th>Cumplimiento</th></tr></thead><tbody>
        {d.habits.filter(h => isDaily(h) && s.perHabit.has(h.id)).map(h => { const p = s.perHabit.get(h.id)!; return <tr key={h.id}><td>{h.name}</td><td>{p.done}</td><td>{p.missed}</td><td>{p.pending}</td><td>{pct(p.done + p.missed ? p.done / (p.done + p.missed) : null)}</td></tr>; })}</tbody></table></div></>}
    <div className="card" style={{ marginTop: 14 }}><h2>Misiones completadas</h2>{d.missions.filter(m => m.status === 'completada' && (m.completedOn ?? '') >= from).length} en este periodo</div>
  </>;
}

function Achievements({ d, today, xp, L }: PP) {
  const st = streaks(d.habits, d.logs, today);
  const A: [string, string, boolean][] = [
    ['Primer paso', 'Completa un hábito', d.logs.some(l => l.status === 'done')],
    ['Semana firme', 'Racha de 7 días', st.best >= 7], ['Mes de hierro', 'Racha de 30 días', st.best >= 30],
    ['Operador', 'Alcanza el nivel 9', L.level >= 9], ['Primera misión', 'Completa una misión', d.missions.some(m => m.status === 'completada')],
    ['Mil de XP', 'Acumula 1000 XP', xp.total >= 1000]];
  return <><h1>Logros</h1><p className="sub">Se calculan a partir de tus registros.</p><div className="grid">{A.map(([t, s, ok]) => <div key={t} className="card"><b>{t}</b><div className="mut">{s}</div><span className={`tag ${ok ? 'ok' : ''}`}>{ok ? 'Desbloqueado' : 'Bloqueado'}</span></div>)}</div></>;
}

function Config({ d, run, setAsk, say, reload }: PP & { reload: () => Promise<void> }) {
  const s = d.settings; const set = (c: Partial<Settings>) => run(() => saveSettings({ ...s, ...c }));
  const file = useRef<HTMLInputElement>(null);
  const exp = async () => { try { const b = new Blob([await exportAll()], { type: 'application/json' }); const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = `imperium-protocol-${key(new Date())}.json`; a.click(); URL.revokeObjectURL(a.href); say('Copia exportada'); } catch { say('No se pudo exportar la copia.', true); } };
  const imp = async (f: File) => { const text = await f.text(); let o: any; try { o = JSON.parse(text); } catch { return say('El archivo no es un JSON válido. Los datos actuales no se han modificado.', true); }
    const { validateBackup } = await import('./logic/core.ts'); const v = validateBackup(o);
    if (!v.ok) return say(`Copia rechazada: ${v.errors.join(' ')} Los datos actuales no se han modificado.`, true);
    setAsk({ text: `Se reemplazarán TODOS los datos actuales por la copia (${o.habits.length} hábitos, ${o.logs.length} registros, ${o.missions.length} misiones). ¿Continuar?`, ok: async () => { try { const r = await importAll(text); say(r.ok ? 'Copia restaurada' : r.errors.join(' '), !r.ok); await reload(); } catch { say('La restauración falló y no se aplicó ningún cambio.', true); } } }); };
  const num = (k: 'habitXp' | 'dailyBonus' | 'weeklyBonus', l: string) => <label>{l}<input type="number" min={0} value={s[k]} onChange={e => set({ [k]: Math.max(0, Number(e.target.value)) })} /></label>;
  return <>
    <h1>Configuración</h1><p className="sub">Todo se guarda en este navegador. Si borras los datos del sitio o el perfil, se pierden: exporta copias con regularidad.</p>
    <div className="card f"><label>Nombre en el saludo<input value={s.name} onChange={e => set({ name: e.target.value })} /></label>{num('habitXp', 'XP por hábito')}{num('dailyBonus', 'Bonus día completo')}{num('weeklyBonus', 'Bonus semana completa')}
      <label style={{ display: 'flex', gap: 8 }}><input type="checkbox" checked={s.reduceMotion} onChange={e => set({ reduceMotion: e.target.checked })} />Reducir animaciones</label>
      <div><button className="b" onClick={() => set({ habitXp: DEFAULTS.habitXp, dailyBonus: DEFAULTS.dailyBonus, weeklyBonus: DEFAULTS.weeklyBonus })}>Restaurar valores de XP</button></div></div>
    <div className="card row" style={{ marginTop: 14 }}><button className="b pri" onClick={exp}>Exportar copia JSON</button><button className="b" onClick={() => file.current?.click()}>Importar copia</button>
      <input ref={file} type="file" accept="application/json,.json" hidden onChange={e => { const f = e.target.files?.[0]; if (f) imp(f); e.target.value = ''; }} />
      <button className="b dng" onClick={() => setAsk({ text: 'Se borrarán todos los hábitos, registros y misiones. Esta acción no se puede deshacer. ¿Seguro?', ok: () => run(async () => { await wipeAll(); }, 'Datos borrados') })}>Borrar todos los datos</button></div>
  </>;
}
