import Dexie from 'dexie';
import type { Table } from 'dexie';
import { BACKUP_VERSION, DEFAULTS, validateBackup } from './logic/core.ts';
import type { Habit, Log, Mission, Settings } from './logic/core.ts';
import { key } from './logic/dates.ts';

type Meta = { key: string; value: unknown };
class AppDB extends Dexie {
  habits!: Table<Habit, string>; logs!: Table<Log, [string, string]>; missions!: Table<Mission, string>; meta!: Table<Meta, string>;
  constructor() {
    super('imperium-protocol');
    // Migraciones: añadir db.version(2).stores({...}).upgrade(...) sin tocar la versión 1.
    this.version(1).stores({ habits: 'id', logs: '[habitId+date],date', missions: 'id', meta: 'key' });
  }
}
export const db = new AppDB();
export const uid = () => crypto.randomUUID();

const SEED: [string, string][] = [
  ['Cumplir la rutina de entrenamiento programada', 'Físico'], ['Respetar el descanso y la recuperación', 'Descanso y bienestar'],
  ['Estudiar programación', 'Programación'], ['Practicar ciberseguridad', 'Ciberseguridad'], ['Avanzar en proyectos de Imperium Labs', 'Imperium Labs'],
  ['Completar los deberes escolares', 'Estudios'], ['Leer al menos diez páginas', 'Desarrollo personal'], ['Planificar el día', 'Desarrollo personal'],
  ['Mantener una rutina de sueño adecuada', 'Descanso y bienestar']];

export async function loadAll() {
  if (!(await db.meta.get('seeded'))) {
    const t = key(new Date());
    await db.transaction('rw', db.habits, db.meta, async () => {
      await db.habits.bulkPut(SEED.map(([name, category]) => ({ id: uid(), name, category, frequency: 'daily' as const, days: [], weeklyTarget: 1, startDate: t })));
      await db.meta.put({ key: 'seeded', value: true });
    });
  }
  const s = (await db.meta.get('settings'))?.value as Settings | undefined;
  return { habits: await db.habits.toArray(), logs: await db.logs.toArray(), missions: await db.missions.toArray(), settings: { ...DEFAULTS, ...s } };
}
export const saveSettings = (s: Settings) => db.meta.put({ key: 'settings', value: s });

export async function exportAll() {
  const a = await loadAll();
  return JSON.stringify({ app: 'imperium-protocol', version: BACKUP_VERSION, exportedAt: new Date().toISOString(), habits: a.habits, logs: a.logs, missions: a.missions, settings: a.settings }, null, 2);
}
/** Valida primero; solo si es válido reemplaza todo dentro de una única transacción (si falla, no cambia nada). */
export async function importAll(text: string) {
  let o: any; try { o = JSON.parse(text); } catch { return { ok: false, errors: ['El archivo no es un JSON válido.'] }; }
  const v = validateBackup(o); if (!v.ok) return v;
  await db.transaction('rw', db.habits, db.logs, db.missions, db.meta, async () => {
    await Promise.all([db.habits.clear(), db.logs.clear(), db.missions.clear()]);
    await db.habits.bulkPut(o.habits); await db.logs.bulkPut(o.logs); await db.missions.bulkPut(o.missions);
    await db.meta.put({ key: 'settings', value: { ...DEFAULTS, ...(o.settings ?? {}) } }); await db.meta.put({ key: 'seeded', value: true });
  });
  return { ok: true, errors: [] as string[] };
}
export const wipeAll = () => db.transaction('rw', db.habits, db.logs, db.missions, db.meta, async () => { await Promise.all([db.habits.clear(), db.logs.clear(), db.missions.clear(), db.meta.clear()]); await db.meta.put({ key: 'seeded', value: true }); });
