import { addDays, dow, range, weekStart } from './dates.ts';

export type Habit = { id: string; name: string; category: string; xp?: number; frequency: 'daily' | 'days' | 'weekly'; days: number[]; weeklyTarget: number; startDate: string; archivedOn?: string };
export type Log = { habitId: string; date: string; status: 'done' | 'missed'; note?: string };
export type Mission = { id: string; title: string; description: string; category: string; priority: 'alta' | 'media' | 'baja'; status: 'pendiente' | 'progreso' | 'completada' | 'pospuesta' | 'cancelada'; progress: number; xp: number; due?: string; created: string; completedOn?: string; rewardGranted: boolean; notes?: string };
export type Settings = { name: string; habitXp: number; dailyBonus: number; weeklyBonus: number; reduceMotion: boolean };
export const DEFAULTS: Settings = { name: 'Operador', habitXp: 10, dailyBonus: 25, weeklyBonus: 100, reduceMotion: false };
export const RANKS = ['Recluta', 'Aspirante', 'Operador', 'Especialista', 'Estratega', 'Comandante', 'Élite', 'Emperador'];

// --- Programación ---
export const eligible = (h: Habit, k: string) =>
  k >= h.startDate && !(h.archivedOn && k >= h.archivedOn) && (h.frequency !== 'days' || h.days.includes(dow(k)));
export const isDaily = (h: Habit) => h.frequency !== 'weekly'; // los semanales se evalúan por semana
export const index = (logs: Log[]) => new Map(logs.map(l => [`${l.habitId}|${l.date}`, l]));
export type LogIndex = ReturnType<typeof index>;
export const isDone = (ix: LogIndex, h: Habit, k: string) => ix.get(`${h.id}|${k}`)?.status === 'done';

/** Añade o quita un registro: un único registro por hábito y fecha (nunca duplica). */
export function setLog(logs: Log[], habitId: string, date: string, status: Log['status'] | null, note?: string): Log[] {
  const rest = logs.filter(l => !(l.habitId === habitId && l.date === date));
  return status ? [...rest, { habitId, date, status, note }] : rest;
}

// --- XP derivada de los registros válidos ---
export function xpBreakdown(habits: Habit[], logs: Log[], missions: Mission[], s: Settings, today: string) {
  const ix = index(logs);
  const byId = new Map(habits.map(h => [h.id, h]));
  let habit = 0, daily = 0, weekly = 0;
  for (const l of logs) {
    const h = byId.get(l.habitId);
    if (!h || l.status !== 'done' || l.date > today) continue;
    const ok = h.frequency === 'weekly' ? l.date >= h.startDate : eligible(h, l.date);
    if (ok) habit += h.xp ?? s.habitXp;
  }
  if (habits.length) {
    const first = habits.map(h => h.startDate).sort()[0];
    for (const k of range(first, today)) {
      const sch = habits.filter(h => isDaily(h) && eligible(h, k));
      if (sch.length && sch.every(h => isDone(ix, h, k))) daily += s.dailyBonus;
    }
    for (let w = weekStart(first); addDays(w, 6) <= today; w = addDays(w, 7)) {
      const end = addDays(w, 6); let req = 0, met = true;
      for (const h of habits) {
        if (isDaily(h)) for (const k of range(w, end)) { if (eligible(h, k)) { req++; if (!isDone(ix, h, k)) met = false; } }
        else if (eligible(h, end)) { req++; if (range(w, end).filter(k => isDone(ix, h, k)).length < h.weeklyTarget) met = false; }
      }
      if (req && met) weekly += s.weeklyBonus;
    }
  }
  const mission = missions.filter(m => m.rewardGranted).reduce((a, m) => a + m.xp, 0);
  return { habit, daily, weekly, mission, total: habit + daily + weekly + mission };
}

export const xpAt = (level: number) => 50 * level * (level - 1);
export function levelInfo(xp: number) {
  let level = 1; while (xp >= xpAt(level + 1)) level++;
  const from = xpAt(level), to = xpAt(level + 1);
  return { level, rank: RANKS[Math.min(7, Math.floor((level - 1) / 4))], from, to, remaining: to - xp, pct: (xp - from) / (to - from) };
}

/** Completa una misión. La recompensa se concede una sola vez, aunque se reabra y se vuelva a completar. */
export const completeMission = (m: Mission, today: string): Mission => ({ ...m, status: 'completada', progress: 100, completedOn: m.completedOn ?? today, rewardGranted: true });
export const reopenMission = (m: Mission): Mission => ({ ...m, status: 'progreso' });

// --- Rachas ---
export function dayStatus(habits: Habit[], ix: LogIndex, k: string, today: string): 'future' | 'none' | 'success' | 'fail' | 'pending' {
  if (k > today) return 'future';
  const sch = habits.filter(h => isDaily(h) && eligible(h, k));
  if (!sch.length) return 'none';
  if (sch.every(h => isDone(ix, h, k))) return 'success';
  return k === today ? 'pending' : 'fail';
}
export function streaks(habits: Habit[], logs: Log[], today: string) {
  if (!habits.length) return { current: 0, best: 0 };
  const ix = index(logs), days = range(habits.map(h => h.startDate).sort()[0], today);
  let best = 0, run = 0;
  for (const k of days) { const s = dayStatus(habits, ix, k, today); if (s === 'success') best = Math.max(best, ++run); else if (s === 'fail') run = 0; }
  let current = 0;
  for (const k of [...days].reverse()) { const s = dayStatus(habits, ix, k, today); if (s === 'success') current++; else if (s === 'fail') break; }
  return { current, best };
}

// --- Estadísticas: solo oportunidades ya llegadas; pendientes se cuentan aparte y no son incumplimientos ---
export function periodStats(habits: Habit[], logs: Log[], from: string, to: string, today: string) {
  const ix = index(logs), end = to > today ? today : to;
  let done = 0, missed = 0, pending = 0;
  const perHabit = new Map<string, { done: number; missed: number; pending: number }>();
  if (from <= end) for (const k of range(from, end)) for (const h of habits) {
    if (!isDaily(h) || !eligible(h, k)) continue;
    const st = ix.get(`${h.id}|${k}`)?.status, p = perHabit.get(h.id) ?? { done: 0, missed: 0, pending: 0 };
    if (st === 'done') { done++; p.done++; } else if (st === 'missed') { missed++; p.missed++; } else { pending++; p.pending++; }
    perHabit.set(h.id, p);
  }
  const evaluated = done + missed;
  return { done, missed, pending, pct: evaluated ? done / evaluated : null, perHabit };
}

// --- Copia de seguridad ---
export const BACKUP_VERSION = 1;
export function validateBackup(o: any): { ok: boolean; errors: string[] } {
  const errors: string[] = [];
  if (!o || typeof o !== 'object') return { ok: false, errors: ['El archivo no contiene un objeto JSON.'] };
  if (o.app !== 'imperium-protocol') errors.push('No es una copia de IMPERIUM PROTOCOL.');
  if (typeof o.version !== 'number') errors.push('Falta la versión del formato.');
  else if (o.version > BACKUP_VERSION) errors.push(`Versión ${o.version} no compatible (máxima ${BACKUP_VERSION}).`);
  for (const t of ['habits', 'logs', 'missions']) if (!Array.isArray(o[t])) errors.push(`Falta la lista "${t}".`);
  if (!errors.length) {
    if (o.habits.some((h: any) => !h?.id || !h?.name || !h?.startDate)) errors.push('Hay hábitos sin id, nombre o fecha de inicio.');
    if (o.logs.some((l: any) => !l?.habitId || !l?.date || !['done', 'missed'].includes(l?.status))) errors.push('Hay registros con formato inválido.');
    if (o.missions.some((m: any) => !m?.id || !m?.title)) errors.push('Hay misiones sin id o título.');
  }
  return { ok: !errors.length, errors };
}
