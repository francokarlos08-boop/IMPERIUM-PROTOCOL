const pad = (n: number) => String(n).padStart(2, '0');
export const key = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export const parse = (k: string) => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
export const addDays = (k: string, n: number) => { const d = parse(k); d.setDate(d.getDate() + n); return key(d); };
export const dow = (k: string) => parse(k).getDay();
export const weekStart = (k: string) => addDays(k, -((dow(k) + 6) % 7)); // lunes
export const range = (a: string, b: string) => { const r: string[] = []; for (let k = a; k <= b; k = addDays(k, 1)) r.push(k); return r; };
