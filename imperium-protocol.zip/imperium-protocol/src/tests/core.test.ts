import { describe, it, expect } from 'vitest';
import { DEFAULTS, setLog, xpBreakdown, levelInfo, completeMission, reopenMission, streaks, periodStats, validateBackup, eligible } from '../logic/core.ts';
import type { Habit, Log, Mission } from '../logic/core.ts';
import { addDays, range, weekStart } from '../logic/dates.ts';

const H = (id: string, o: Partial<Habit> = {}): Habit => ({ id, name: id, category: 'Físico', frequency: 'daily', days: [], weeklyTarget: 1, startDate: '2026-01-05', ...o });
const done = (id: string, dates: string[]): Log[] => dates.map(date => ({ habitId: id, date, status: 'done' as const }));
const S = DEFAULTS;
const M = (o: Partial<Mission> = {}): Mission => ({ id: 'm', title: 't', description: '', category: 'x', priority: 'media', status: 'pendiente', progress: 0, xp: 50, created: '2026-01-05', rewardGranted: false, ...o });

describe('hábitos y registros', () => {
  it('impide duplicados y permite deshacer', () => {
    let l = setLog([], 'a', '2026-01-05', 'done'); l = setLog(l, 'a', '2026-01-05', 'done');
    expect(l.length).toBe(1);
    expect(setLog(l, 'a', '2026-01-05', null).length).toBe(0);
  });
  it('respeta días programados y archivado', () => {
    const h = H('a', { frequency: 'days', days: [1], archivedOn: '2026-01-20' }); // lunes
    expect(eligible(h, '2026-01-05')).toBe(true);   // lunes
    expect(eligible(h, '2026-01-06')).toBe(false);  // martes
    expect(eligible(h, '2026-01-26')).toBe(false);  // archivado
  });
});

describe('XP', () => {
  const h = [H('a'), H('b')];
  it('hábito + bonus diario, sin duplicar al repetir', () => {
    let l = setLog(setLog([], 'a', '2026-01-05', 'done'), 'b', '2026-01-05', 'done');
    expect(xpBreakdown(h, l, [], S, '2026-01-05').total).toBe(20 + 25);
    l = setLog(setLog(l, 'a', '2026-01-05', null), 'a', '2026-01-05', 'done');
    expect(xpBreakdown(h, l, [], S, '2026-01-05').total).toBe(45);
  });
  it('sin bonus si falta un hábito', () => {
    expect(xpBreakdown(h, done('a', ['2026-01-05']), [], S, '2026-01-05').total).toBe(10);
  });
  it('bonus semanal solo con semana completa y terminada', () => {
    const days = range('2026-01-05', '2026-01-11');
    const l = [...done('a', days), ...done('b', days)];
    expect(xpBreakdown(h, l, [], S, '2026-01-10').weekly).toBe(0);
    expect(xpBreakdown(h, l, [], S, '2026-01-11').weekly).toBe(100);
  });
  it('no concede XP por días futuros ni días no programados', () => {
    const w = [H('a', { frequency: 'days', days: [1] })];
    expect(xpBreakdown(w, done('a', ['2026-01-06']), [], S, '2026-01-10').habit).toBe(0);
    expect(xpBreakdown(h, done('a', ['2026-02-01']), [], S, '2026-01-10').habit).toBe(0);
  });
  it('misión: recompensa única aunque se reabra', () => {
    let m = completeMission(M(), '2026-01-06');
    m = completeMission(reopenMission(m), '2026-01-08');
    expect(m.completedOn).toBe('2026-01-06');
    expect(xpBreakdown([], [], [m], S, '2026-01-10').mission).toBe(50);
    expect(xpBreakdown([], [], [reopenMission(m)], S, '2026-01-10').mission).toBe(50);
  });
  it('nivel y rango', () => {
    expect(levelInfo(0)).toMatchObject({ level: 1, rank: 'Recluta', remaining: 100 });
    expect(levelInfo(100).level).toBe(2);
    expect(levelInfo(299).level).toBe(2);
    expect(levelInfo(300).level).toBe(3);
    expect(levelInfo(50 * 5 * 4).rank).toBe('Aspirante'); // nivel 5
  });
});

describe('rachas y estadísticas', () => {
  const h = [H('a')];
  it('racha consecutiva; hoy pendiente no la rompe', () => {
    const l = done('a', ['2026-01-05', '2026-01-06', '2026-01-07']);
    expect(streaks(h, l, '2026-01-08')).toEqual({ current: 3, best: 3 });
  });
  it('un día pasado sin registro rompe la racha', () => {
    const l = done('a', ['2026-01-05', '2026-01-07', '2026-01-08']);
    expect(streaks(h, l, '2026-01-08')).toEqual({ current: 2, best: 2 });
  });
  it('días sin hábitos programados no rompen la racha', () => {
    const w = [H('a', { frequency: 'days', days: [1, 3] })]; // lun y mié
    expect(streaks(w, done('a', ['2026-01-05', '2026-01-07']), '2026-01-08').current).toBe(2);
  });
  it('cambio de mes y año, febrero bisiesto', () => {
    expect(addDays('2026-12-31', 1)).toBe('2027-01-01');
    expect(addDays('2028-02-28', 1)).toBe('2028-02-29');
    expect(addDays('2027-02-28', 1)).toBe('2027-03-01');
    expect(weekStart('2026-01-01')).toBe('2025-12-29');
    const l = done('a', range('2026-12-30', '2027-01-02'));
    expect(streaks([H('a', { startDate: '2026-12-30' })], l, '2027-01-02').current).toBe(4);
  });
  it('porcentaje: pendiente ≠ incumplido, futuros excluidos', () => {
    const l: Log[] = [...done('a', ['2026-01-05', '2026-01-06']), { habitId: 'a', date: '2026-01-07', status: 'missed' }];
    const s = periodStats(h, l, '2026-01-05', '2026-01-31', '2026-01-09');
    expect(s).toMatchObject({ done: 2, missed: 1, pending: 2 });
    expect(s.pct).toBeCloseTo(2 / 3);
    expect(periodStats(h, [], '2026-01-05', '2026-01-09', '2026-01-09').pct).toBeNull();
  });
  it('ignora hábitos no programados', () => {
    const w = [H('a', { frequency: 'days', days: [1] })];
    const s = periodStats(w, done('a', ['2026-01-05']), '2026-01-05', '2026-01-11', '2026-01-11');
    expect(s).toMatchObject({ done: 1, missed: 0, pending: 0 });
  });
});

describe('copias de seguridad', () => {
  const ok = { app: 'imperium-protocol', version: 1, habits: [H('a')], logs: done('a', ['2026-01-05']), missions: [M()] };
  it('acepta una copia válida y sobrevive a JSON', () => {
    expect(validateBackup(JSON.parse(JSON.stringify(ok))).ok).toBe(true);
  });
  it('rechaza archivos inválidos o de versión futura', () => {
    expect(validateBackup(null).ok).toBe(false);
    expect(validateBackup({ ...ok, app: 'otra' }).ok).toBe(false);
    expect(validateBackup({ ...ok, version: 99 }).ok).toBe(false);
    expect(validateBackup({ ...ok, logs: [{ habitId: 'a' }] }).ok).toBe(false);
    expect(validateBackup({ ...ok, habits: 'x' }).errors.length).toBeGreaterThan(0);
  });
});
